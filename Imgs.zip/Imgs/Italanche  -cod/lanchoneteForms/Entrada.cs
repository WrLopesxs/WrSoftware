﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lanchoneteForms
{
    public partial class Entrada : Form
    {
        public Entrada()
        {
            InitializeComponent();
            EfectTime();
        }

        private bool Efect = true;

        private void splashTimer_Tick(object sender, EventArgs e)
        {
            if (Efect)
            {
                this.Opacity -= 0.01D;
            }
            if (this.Opacity == 0)
            {
                Efect = false;

                splashTimer.Enabled = false;
                Form frmLogin = new FormLogin();
                frmLogin.Show();
                this.Hide();
            }
        }
        private void EfectTime()
        {
            splashTimer.Interval = 70;
            splashTimer.Tick += new EventHandler(splashTimer_Tick);
            splashTimer.Enabled = true;
            this.Opacity = 1;
        }

        private void Entrada_Load(object sender, EventArgs e)
        {

        }

        private void Entrada_Load_1(object sender, EventArgs e)
        {

        }
    }
}

