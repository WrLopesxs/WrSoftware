namespace lanchoneteForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new Entrada());
            Application.Run(new FormLogin());
        }
    }
}
