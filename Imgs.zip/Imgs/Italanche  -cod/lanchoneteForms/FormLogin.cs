﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;

namespace lanchoneteForms
{
    public partial class FormLogin : Form
    {
        private string connStr = "Data Source=172.16.255.252;User ID=240321_66_A_1_2024;Password=A12345678a;";

        public FormLogin()
        {
            InitializeComponent();



        }
        private string CalcularHash(string senha)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Encoding específico se necessário
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(senha));

                // Formato alternativo de conversão
                return BitConverter.ToString(bytes).Replace("-", "").ToLower();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string usuario = txtUsuario.Text.Trim();
            string senhaDigitada = txtSenha.Text;
            string senhaHash = CalcularHash(senhaDigitada);

            // DEBUG - Mostra os valores no console
            Console.WriteLine($"Usuário digitado: {usuario}");
            Console.WriteLine($"Senha digitada: {senhaDigitada}");
            Console.WriteLine($"Hash gerado: {senhaHash}");

            string query = "SELECT Senha, NivelAcesso FROM UsuariosLancho WHERE NomeUsuario = @NomeUsuario";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@NomeUsuario", usuario);

                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string hashArmazenado = reader["Senha"].ToString();
                        Console.WriteLine($"Hash no banco: {hashArmazenado}"); // DEBUG

                        if (hashArmazenado == senhaHash)
                        {
                            string nivelAcesso = reader["NivelAcesso"].ToString();
                            this.Hide();
                            var formPrincipal = new formLanchonete(nivelAcesso);
                            formPrincipal.ShowDialog();
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Hash não confere!\n" +
                                          $"Digitado: {senhaHash}\n" +
                                          $"Banco: {hashArmazenado}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Usuário não encontrado!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Erro: {ex.Message}");
                }
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}

