using System.Data;
using System.Text;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Globalization;
using System.Reflection;

namespace lanchoneteForms
{
    public partial class formLanchonete : Form
    {
        int conn = 0;
        int contadorItens = 0;
        string connStr = "Data Source=172.16.255.252;User ID=240321_66_A_1_2024;Password=A12345678a;";

        public formLanchonete(string nivelAcesso)
        {
            InitializeComponent();
            CarregarLanches();
            CarregarBebidas();
        }

        public class ItemPedido
        {
            public int ProdutoId { get; set; }
            public int Quantidade { get; set; }
            public string Descricao { get; set; }
            public bool IsBebida { get; set; }
        }

        private void CarregarLanches()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string query = "SELECT id, nome FROM Produtos";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        cmbLanche.Items.Add(nome);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar os lanches: " + ex.Message);
            }
        }

        private void CarregarBebidas()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    conn.Open();
                    string query = "SELECT id, nome, pre�o FROM Bebidas";
                    SqlCommand cmd = new SqlCommand(query, conn);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        string nome = reader["nome"].ToString();
                        double preco = Convert.ToDouble(reader["pre�o"]);
                        cmbBeb.Items.Add($"{nome} - R${preco:N2}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar bebidas: {ex.Message}");
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblHora.Text = "Hor�rio: " + DateTime.Now.ToString("HH:mm:ss");
        }

        private void comboBoxLanche_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbLanche.SelectedItem == null)
                return;
            if (string.IsNullOrEmpty(txtQtd.Text))
            {
                txtQtd.Text = "1";
            }

            string nomeLanche = cmbLanche.SelectedItem.ToString();
            double preco = 0.0;

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                string query = "SELECT pre�o FROM Produtos WHERE nome = @nome";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nome", nomeLanche);
                    object resultado = cmd.ExecuteScalar();

                    if (resultado != null && double.TryParse(resultado.ToString(), out preco))
                    {
                        cmbPre�o.Text = preco.ToString("C");

                        if (int.TryParse(txtQtd.Text, out int quantidade) && quantidade >= 0)
                        {
                            double valorTotal = preco * quantidade;
                            txtVitem.Text = valorTotal.ToString("C");
                        }
                        else
                        {
                            txtVitem.Text = preco.ToString("C");
                        }
                    }
                    else
                    {
                        cmbPre�o.Text = "R$0,00";
                        txtVitem.Text = "R$0,00";
                    }
                }
            }
        }

        private void btnNovoPedido_Click(object sender, EventArgs e)
        {
            int numeroPedido = ObterProximoNumeroPedido();
            lblNumeroPedido.Text = numeroPedido.ToString();
            lblNumeroPedidoItens.Text = numeroPedido.ToString();

            btnPedidoXml.Enabled = true;
            btnPedidoTxt.Enabled = true;
            btnLancarItens.Enabled = true;
            btnResumoPedidos.Enabled = true;
            btnJson.Enabled = true;
            BtnFInalizarPed.Enabled = true;
        }

        private int ObterProximoNumeroPedido()
        {
            string caminho = "pedido.xml";
            if (!File.Exists(caminho)) return 1;

            try
            {
                var doc = XDocument.Load(caminho);
                var numeros = doc.Descendants("Pedido").Select(p => (int)p.Element("NumeroPedido"));
                return numeros.Any() ? numeros.Max() + 1 : 1;
            }
            catch
            {
                return 1;
            }
        }

        private void btnLancarItens_Click(object sender, EventArgs e)
        {
            TabPages.SelectTab(tbItem);
        }

        private void txtQtd_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
                e.Handled = true;
        }

        private void radioButtonCondSim_CheckedChanged(object sender, EventArgs e)
        {
            GrbCOnd.Enabled = true;
        }

        private void radioButtonCondNao_CheckedChanged(object sender, EventArgs e)
        {
            foreach (Control ctrl in GrbCOnd.Controls)
            {
                if (ctrl is CheckBox chk)
                    chk.Checked = false;
            }
            GrbCOnd.Enabled = false;
        }

        private void radioButtonBebSim_CheckedChanged(object sender, EventArgs e)
        {
            grbBeb.Enabled = true;
        }

        private void radioButtonBebNao_CheckedChanged(object sender, EventArgs e)
        {
            grbBeb.Enabled = false;
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbLanche.SelectedItem == null)
                {
                    MessageBox.Show("Selecione um lanche primeiro!");
                    return;
                }

                string nomeLanche = cmbLanche.SelectedItem.ToString();
                double precoLanche = ObterPrecoDoBanco(nomeLanche, "Produtos");

                if (!int.TryParse(txtQtd.Text, out int quantidade) || quantidade <= 0)
                {
                    MessageBox.Show("Quantidade inv�lida! Digite um n�mero positivo.");
                    txtQtd.Text = "1";
                    return;
                }

                double totalLanche = precoLanche * quantidade;

                // Corrigido aqui - usando o pre�o obtido do banco diretamente
                dataGridView1.Rows.Add(
                    ++conn,
                    cmbLanche.SelectedItem,
                    txtQtd.Text,
                    "R$" + precoLanche.ToString("N2"), // Pre�o unit�rio formatado
                    "R$" + totalLanche.ToString("N2")   // Total formatado
                );

                double valorTotal = double.Parse(lblValorTotal.Text.Replace("R$", "").Trim()) + totalLanche;
                lblValorTotal.Text = valorTotal.ToString("C");

                if (radioButtonCondSim.Checked)
                {
                    foreach (Control ctrl in GrbCOnd.Controls)
                    {
                        if (ctrl is CheckBox cb && cb.Checked)
                        {
                            dataGridView1.Rows.Add("-> ", cb.Text, "", "", "");
                        }
                    }
                }

                if (radioButtonBebSim.Checked && cmbBeb.SelectedIndex >= 0)
                {
                    string bebidaTexto = cmbBeb.SelectedItem.ToString();
                    int i = bebidaTexto.IndexOf("$");
                    string valorBebidaStr = bebidaTexto.Substring(i + 1).Trim();

                    if (Double.TryParse(valorBebidaStr, out double number))
                    {
                        dataGridView1.Rows.Add(
                            ++conn,
                            cmbBeb.Text,
                            "1",
                            "R$" + number.ToString("N2"),
                            "R$" + number.ToString("N2")
                        );
                        valorTotal += number;
                        lblValorTotal.Text = valorTotal.ToString("C");
                    }
                    else
                    {
                        MessageBox.Show("Formato de valor da bebida inv�lido!");
                        return;
                    }
                }

                dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.Rows.Count - 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao adicionar item: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private double ObterPrecoDoBanco(string nomeItem, string tabela)
        {
            double preco = 0;
            string query = $"SELECT pre�o FROM {tabela} WHERE nome = @nome";

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nome", nomeItem);
                    object result = cmd.ExecuteScalar();

                    if (result != null && !Convert.IsDBNull(result))
                    {
                        preco = Convert.ToDouble(result);
                    }
                }
            }
            return preco;
        }

        private void btnRemover_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.IsNewRow)
                return;

            try
            {
                bool isCondimento = dataGridView1.CurrentRow.Cells["colunaItem"].Value?.ToString().Trim() == "->";
                bool isItemPrincipal = !isCondimento && dataGridView1.CurrentRow.Cells["colunaTotal"].Value != null;

                if (isCondimento)
                {
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
                }
                else if (isItemPrincipal)
                {
                    double valorItem = double.Parse(dataGridView1.CurrentRow.Cells["colunaTotal"].Value.ToString()
                        .Replace("R$", "").Trim());

                    int rowIndex = dataGridView1.CurrentRow.Index;
                    dataGridView1.Rows.Remove(dataGridView1.CurrentRow);

                    while (rowIndex < dataGridView1.Rows.Count &&
                           !dataGridView1.Rows[rowIndex].IsNewRow &&
                           dataGridView1.Rows[rowIndex].Cells["colunaItem"].Value?.ToString().Trim() == "->")
                    {
                        dataGridView1.Rows.RemoveAt(rowIndex);
                    }

                    double valorTotal = double.Parse(lblValorTotal.Text.Replace("R$", "").Trim());
                    lblValorTotal.Text = (valorTotal - valorItem).ToString("C");

                    ReordenarItens();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao remover item: {ex.Message}");
            }
        }

        private void ReordenarItens()
        {
            int novoNumeroItem = 1;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow && row.Cells["colunaItem"].Value != null)
                {
                    string valorAtual = row.Cells["colunaItem"].Value.ToString().Trim();

                    if (valorAtual != "->" && !string.IsNullOrEmpty(valorAtual))
                    {
                        row.Cells["colunaItem"].Value = novoNumeroItem++;
                    }
                }
            }
            conn = novoNumeroItem - 1;
        }

        private void btnPedidoXml_Click(object sender, EventArgs e)
        {
            string caminho = "pedido.xml";
            try
            {
                var doc = File.Exists(caminho) ? XDocument.Load(caminho) : new XDocument(new XElement("Pedidos"));

                XElement novoPedido = new XElement("Pedido",
                    new XElement("NumeroPedido", lblNumeroPedido.Text.Trim()),
                    new XElement("Cliente", textBoxCliente.Text.Trim()),
                    new XElement("DataPedido", dtpInicio.Value.ToString("yyyy-MM-dd HH:mm:ss")),
                    new XElement("TotalPedido", lblValorTotal.Text.Replace("R$", "").Trim()),
                    new XElement("Observacao", textBoxObs.Text.Trim()),
                    new XElement("Itens", ObterItensParaXml()),
                    new XElement("Condimentos", ObterCondimentosParaXml())
                );

                doc.Root.Add(novoPedido);
                doc.Save(caminho);
                btnCancelar();
                MessageBox.Show("Pedido salvo com sucesso em XML!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar XML: {ex.Message}");
            }
        }

        private List<XElement> ObterItensParaXml()
        {
            var itens = new List<XElement>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow || row.Cells["colunaItem"].Value == null) continue;

                string valorItem = row.Cells["colunaItem"].Value.ToString().Trim();
                if (valorItem == "->") continue;

                itens.Add(new XElement("Item",
                    new XElement("NumeroItem", valorItem),
                    new XElement("Descricao", row.Cells["colunaDescricao"].Value?.ToString()),
                    new XElement("Quantidade", row.Cells["colunaQtd"].Value?.ToString()),
                    new XElement("PrecoUnitario", row.Cells["colunaValorUnid"].Value?.ToString()?.Replace("R$", "").Trim()),
                    new XElement("TotalItem", row.Cells["colunaTotal"].Value?.ToString()?.Replace("R$", "").Trim())
                ));
            }

            return itens;
        }

        private List<XElement> ObterCondimentosParaXml()
        {
            var condimentos = new List<XElement>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow || row.Cells["colunaItem"].Value == null) continue;

                if (row.Cells["colunaItem"].Value.ToString().Trim() == "->")
                {
                    condimentos.Add(new XElement("Condimento",
                        row.Cells["colunaDescricao"].Value?.ToString()));
                }
            }

            return condimentos;
        }

        private void btnPedidoTxt_Click(object sender, EventArgs e)
        {
            string caminho = "pedidos.txt"; // Arquivo �nico para todos os pedidos

            try
            {
                StringBuilder conteudo = new StringBuilder();

                // Se o arquivo j� existe, l� o conte�do atual
                if (File.Exists(caminho))
                {
                    conteudo.Append(File.ReadAllText(caminho));
                    conteudo.AppendLine(new string('-', 50)); // Separador
                }

                // Adiciona o novo pedido
                conteudo.AppendLine("N�mero do Pedido: " + lblNumeroPedido.Text.Trim());
                conteudo.AppendLine("Cliente: " + textBoxCliente.Text.Trim());
                conteudo.AppendLine("Data do Pedido: " + dtpInicio.Value.ToString("yyyy-MM-dd HH:mm:ss"));
                conteudo.AppendLine("Total do Pedido: " + lblValorTotal.Text.Replace("R$", "").Trim());
                conteudo.AppendLine("Observa��o: " + textBoxObs.Text.Trim());
                conteudo.AppendLine("\nItens:");

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    if (row.IsNewRow) continue;

                    var numeroItem = row.Cells["colunaItem"].Value?.ToString().Trim();
                    var descricao = row.Cells["colunaDescricao"].Value?.ToString().Trim();
                    var quantidade = row.Cells["colunaQtd"].Value?.ToString().Trim();
                    var precoUnitario = row.Cells["colunaValorUnid"].Value?.ToString().Trim();
                    var total = row.Cells["colunaTotal"].Value?.ToString().Trim();

                    if (numeroItem == "->")
                    {
                        conteudo.AppendLine("  - Condimento: " + descricao);
                    }
                    else
                    {
                        conteudo.AppendLine($"  Item {numeroItem}: {descricao}");
                        conteudo.AppendLine($"    Quantidade: {quantidade}");
                        conteudo.AppendLine($"    Pre�o Unit�rio: {precoUnitario}");
                        conteudo.AppendLine($"    Total: {total}");
                        conteudo.AppendLine();
                    }
                }

                File.WriteAllText(caminho, conteudo.ToString());
                MessageBox.Show("Pedido adicionado ao arquivo TXT acumulativo!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar TXT: {ex.Message}");
            }
        }

        public void btnCancelar()
        {
            conn = 0;
            dataGridView1.Rows.Clear();
            lblValorTotal.Text = 0.ToString("C");

            textBoxCliente.Clear();
            textBoxObs.Clear();
            txtQtd.Text = "1";
            txtVitem.Clear();
            cmbLanche.SelectedIndex = -1;

            cmbPre�o.Text = "";
            cmbBeb.SelectedIndex = -1;

            foreach (Control ctrl in groupBox1.Controls)
            {
                if (ctrl is CheckBox cb)
                    cb.Checked = false;
            }

            radioButtonCondNao.Checked = true;
            radioButtonBebNao.Checked = true;

            GrbCOnd.Enabled = false;
            grbBeb.Enabled = false;

            btnPedidoXml.Enabled = false;
            btnPedidoTxt.Enabled = false;
            btnLancarItens.Enabled = false;
            btnResumoPedidos.Enabled = false;
            BtnFInalizarPed.Enabled = false;

            TabPages.SelectTab(tbDp);
            lblNumeroPedido.Text = "?";
        }

        private void btnResumoPedidos_Click(object sender, EventArgs e)
        {
            TabPages.SelectTab(tbPr);

            StringBuilder resumo = new StringBuilder();

            resumo.AppendLine(
                $"{"Item".PadRight(15)}" +
                $"{"Descri��o".PadRight(30)}" +
                $"{"Qtd".PadRight(10)}" +
                $"{"$Unid".PadRight(15)}" +
                $"{"Total".PadRight(15)}");

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    string item = row.Cells["colunaItem"].Value?.ToString() ?? "";
                    string descricao = row.Cells["colunaDescricao"].Value?.ToString() ?? "";
                    string qtd = row.Cells["colunaQtd"].Value?.ToString() ?? "";
                    string valorUnid = row.Cells["colunaValorUnid"].Value?.ToString() ?? "";
                    string total = row.Cells["colunaTotal"].Value?.ToString() ?? "";

                    resumo.AppendLine(
                        $"{item.PadRight(15)}{descricao.PadRight(30)}{qtd.PadRight(10)}{valorUnid.PadRight(15)}{total.PadRight(15)}");
                }
            }

            lblResumo.Text += "Pedido N� ";
            lblResumo.Text += lblNumeroPedido.Text + "\n";
            lblResumo.Text += resumo.ToString();
            lblResumo.Text += "-------------------------------------" + "\n";

            MessageBox.Show("Resumo salvo");
        }

        private void btnJson_Click(object sender, EventArgs e)
        {
            string caminho = "pedidos.json"; // Arquivo �nico para todos os pedidos

            try
            {
                List<object> pedidos = new List<object>();

                // Se o arquivo j� existe, carrega os pedidos anteriores
                if (File.Exists(caminho))
                {
                    string jsonExistente = File.ReadAllText(caminho);
                    pedidos = JsonSerializer.Deserialize<List<object>>(jsonExistente) ?? new List<object>();
                }

                // Adiciona o novo pedido
                var novoPedido = new
                {
                    NumeroPedido = lblNumeroPedido.Text.Trim(),
                    Cliente = textBoxCliente.Text.Trim(),
                    DataPedido = dtpInicio.Value.ToString("yyyy-MM-dd HH:mm:ss"),
                    TotalPedido = lblValorTotal.Text.Replace("R$", "").Trim(),
                    Observacao = textBoxObs.Text.Trim(),
                    Itens = ObterItensDoGrid(),
                    Condimentos = ObterCondimentosDoGrid()
                };

                pedidos.Add(novoPedido);

                // Salva todos os pedidos
                string json = JsonSerializer.Serialize(pedidos, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });

                File.WriteAllText(caminho, json);
                MessageBox.Show("Pedido adicionado ao arquivo JSON acumulativo!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao salvar JSON: {ex.Message}");
            }
        }

        private List<object> ObterItensDoGrid()
        {
            var itens = new List<object>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow || row.Cells["colunaItem"].Value == null) continue;

                string valorItem = row.Cells["colunaItem"].Value.ToString().Trim();
                if (valorItem == "->") continue;

                itens.Add(new
                {
                    NumeroItem = valorItem,
                    Descricao = row.Cells["colunaDescricao"].Value?.ToString(),
                    Quantidade = row.Cells["colunaQtd"].Value?.ToString(),
                    PrecoUnitario = row.Cells["colunaValorUnid"].Value?.ToString()?.Replace("R$", "").Trim(),
                    TotalItem = row.Cells["colunaTotal"].Value?.ToString()?.Replace("R$", "").Trim()
                });
            }

            return itens;
        }

        private List<string> ObterCondimentosDoGrid()
        {
            var condimentos = new List<string>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow || row.Cells["colunaItem"].Value == null) continue;

                if (row.Cells["colunaItem"].Value.ToString().Trim() == "->")
                {
                    condimentos.Add(row.Cells["colunaDescricao"].Value?.ToString());
                }
            }

            return condimentos;
        }

        private void txtQtd_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtQtd.Text) || !int.TryParse(txtQtd.Text, out _))
            {
                txtQtd.Text = "1";
            }

            if (cmbLanche.SelectedItem != null)
            {
                comboBoxLanche_SelectedIndexChanged(null, null);
            }
        }

        private void BtnFInalizarPed_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.Rows.Count == 0 || dataGridView1.Rows[0].IsNewRow)
                {
                    MessageBox.Show("Nenhum item no pedido para finalizar!");
                    return;
                }

                if (!int.TryParse(lblNumeroPedido.Text, out int pedidoId))
                {
                    MessageBox.Show("N�mero de pedido inv�lido!");
                    return;
                }

                if (!VerificarEstoqueDisponivel())
                {
                    MessageBox.Show("Alguns itens n�o possuem estoque suficiente!");
                    return;
                }

                FinalizarPedido(pedidoId);

                MessageBox.Show("Pedido finalizado com sucesso e estoque atualizado!");
                MessageBox.Show("Salve como xml agora pra finalizar seu pedido");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao finalizar pedido: {ex.Message}");
            }
        }

        private bool VerificarEstoqueDisponivel()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connStr))
                {
                    connection.Open();

                    foreach (DataGridViewRow row in dataGridView1.Rows)
                    {
                        if (row.IsNewRow || row.Cells["colunaItem"].Value == null)
                            continue;

                        string itemValue = row.Cells["colunaItem"].Value.ToString().Trim();
                        if (itemValue == "->") continue;

                        string descricao = row.Cells["colunaDescricao"].Value?.ToString().Trim();
                        if (string.IsNullOrEmpty(descricao)) continue;

                        bool isBebida = descricao.Contains("- R$");
                        string nomeItem = isBebida ? descricao.Split('-')[0].Trim() : descricao;
                        string tabela = isBebida ? "Bebidas" : "Produtos";

                        if (!int.TryParse(row.Cells["colunaQtd"].Value?.ToString(), out int quantidade))
                            continue;

                        string query = $"SELECT estoque FROM {tabela} WHERE nome = @nome";

                        using (SqlCommand cmd = new SqlCommand(query, connection))
                        {
                            cmd.Parameters.AddWithValue("@nome", nomeItem);
                            object result = cmd.ExecuteScalar();

                            if (result == null)
                            {
                                MessageBox.Show($"Item '{nomeItem}' n�o encontrado na tabela '{tabela}'.");
                                return false;
                            }

                            int estoqueAtual = Convert.ToInt32(result);
                            if (estoqueAtual < quantidade)
                            {
                                MessageBox.Show($"Estoque insuficiente para '{nomeItem}' na tabela '{tabela}'. Dispon�vel: {estoqueAtual}, Solicitado: {quantidade}");
                                return false;
                            }
                        }
                    }

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao verificar estoque: {ex.Message}");
                return false;
            }
        }

        private List<ItemPedido> ObterItensPedido(SqlConnection connection, SqlTransaction transaction)
        {
            var itens = new List<ItemPedido>();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.IsNewRow || row.Cells["colunaItem"].Value == null)
                    continue;

                string itemValue = row.Cells["colunaItem"].Value.ToString().Trim();
                if (itemValue == "->") continue;

                string descricao = row.Cells["colunaDescricao"].Value?.ToString();
                if (!int.TryParse(row.Cells["colunaQtd"].Value?.ToString(), out int quantidade))
                    continue;

                bool isBebida = descricao.Contains("- R$");
                string nomeItem = isBebida ? descricao.Split('-')[0].Trim() : descricao;
                string tabela = isBebida ? "Bebidas" : "Produtos";

                string query = $"SELECT id FROM {tabela} WHERE nome = @nome";
                using (SqlCommand cmd = new SqlCommand(query, connection, transaction))
                {
                    cmd.Parameters.AddWithValue("@nome", nomeItem);
                    object result = cmd.ExecuteScalar();

                    if (result == null)
                    {
                        MessageBox.Show($"Item '{nomeItem}' n�o encontrado na tabela '{tabela}'.");
                        continue;
                    }

                    itens.Add(new ItemPedido
                    {
                        ProdutoId = Convert.ToInt32(result),
                        Quantidade = quantidade,
                        Descricao = nomeItem,
                        IsBebida = isBebida
                    });
                }
            }

            return itens;
        }

        public void FinalizarPedido(int pedidoId)
        {
            using (var connection = new SqlConnection(connStr))
            {
                connection.Open();

                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        var itens = ObterItensPedido(connection, transaction);

                        foreach (var item in itens)
                        {
                            AtualizarEstoque(item, connection, transaction);
                        }

                        RegistrarPedidoNoBanco(pedidoId, connection, transaction);

                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        throw;
                    }
                }
            }
        }

        private void AtualizarEstoque(ItemPedido item, SqlConnection connection, SqlTransaction transaction)
        {
            string tabela = item.IsBebida ? "Bebidas" : "Produtos";

            string sqlSelect = $"SELECT estoque FROM {tabela} WHERE id = @id";
            int estoqueAtual;
            using (var cmd = new SqlCommand(sqlSelect, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@id", item.ProdutoId);
                object result = cmd.ExecuteScalar();

                if (result == null)
                    throw new Exception($"Produto {item.ProdutoId} n�o encontrado na tabela {tabela}.");

                estoqueAtual = Convert.ToInt32(result);
            }

            if (estoqueAtual < item.Quantidade)
                throw new Exception(
                    $"Estoque insuficiente para o item {item.Descricao}. " +
                    $"Dispon�vel: {estoqueAtual}, solicitado: {item.Quantidade}");

            string sqlUpdate = $"UPDATE {tabela} SET estoque = estoque - @qtd WHERE id = @id";
            using (var cmd = new SqlCommand(sqlUpdate, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@qtd", item.Quantidade);
                cmd.Parameters.AddWithValue("@id", item.ProdutoId);
                cmd.ExecuteNonQuery();
            }
        }

        private void RegistrarPedidoNoBanco(int pedidoId, SqlConnection connection, SqlTransaction transaction)
        {

            decimal totalPedido = 0m;
            if (!decimal.TryParse(lblValorTotal.Text
                                        .Replace("R$", "")
                                        .Trim(),
                                    NumberStyles.Any,
                                    new CultureInfo("pt-BR"),
                                    out totalPedido))
            {
                MessageBox.Show("Total inv�lido!");
                return;
            }

            const string sql = @"INSERT INTO Pedidos
     (id, cliente, total, observacao, data_pedido)
     VALUES (@id, @cliente, @total, @observacao, @data_pedido)";
            const string sql2 = @"INSERT INTO PedidosItens(pedido_id, item_nome, quantidade, preco_unitario)
     VALUES (@pedido_id, @item_nome, @quantidade, @preco_unitario)";


            using (var cmd = new SqlCommand(sql, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@id", pedidoId);
                cmd.Parameters.AddWithValue("@cliente", textBoxCliente.Text);
                cmd.Parameters.AddWithValue("@total", totalPedido);
                cmd.Parameters.AddWithValue("@observacao", textBoxObs.Text);
                cmd.Parameters.AddWithValue("@data_pedido", DateTime.Now);

                cmd.ExecuteNonQuery();
            }


            using (var cmd = new SqlCommand(sql2, connection, transaction))
            {

                cmd.Parameters.Add("@pedido_id", SqlDbType.Int);
                cmd.Parameters.Add("@item_nome", SqlDbType.NVarChar);
                cmd.Parameters.Add("@quantidade", SqlDbType.Decimal);
                cmd.Parameters.Add("@preco_unitario", SqlDbType.Decimal);

                foreach (DataGridViewRow row in dataGridView1.Rows)
                {

                    if (!row.IsNewRow)
                    {
                        string item = row.Cells["colunaDescricao"].Value?.ToString() ?? "";
                        string qtd = row.Cells["colunaQtd"].Value?.ToString() ?? "0";
                        string valorUnid = row.Cells["colunaValorUnid"].Value?.ToString() ?? "0";
                        valorUnid = valorUnid.Replace("R$", "").Trim();


                        if (item.Contains("- R$"))
                        {
                            item = item.Split('-')[0].Trim();
                        }

                        if (!decimal.TryParse(qtd, NumberStyles.Any, new CultureInfo("pt-BR"), out decimal quantidade))
                            quantidade = 0m;

                        if (!decimal.TryParse(valorUnid, NumberStyles.Any, new CultureInfo("pt-BR"), out decimal precoUnitario))
                            precoUnitario = 0m;

                        cmd.Parameters["@pedido_id"].Value = pedidoId;
                        cmd.Parameters["@item_nome"].Value = item;
                        cmd.Parameters["@quantidade"].Value = quantidade;
                        cmd.Parameters["@preco_unitario"].Value = precoUnitario;

                        cmd.ExecuteNonQuery();
                    }
                }
            }
        }

        private void btnFiltrar_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                string query = "SELECT * FROM Pedidos WHERE data_pedido BETWEEN @dataInicio AND @dataFim";

                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@dataInicio", dtpInicio.Value.Date);
                cmd.Parameters.AddWithValue("@dataFim", dtpFim.Value.Date);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataTable tabela = new DataTable();

                conn.Open();
                adapter.Fill(tabela);
                conn.Close();

                dataGridView1.DataSource = tabela;
            }
        }
    }
}
            
        
    
