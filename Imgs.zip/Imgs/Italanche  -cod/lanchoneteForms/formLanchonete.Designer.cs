﻿namespace lanchoneteForms
{
    partial class formLanchonete
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(formLanchonete));
            groupBoxAcoes = new GroupBox();
            BtnFInalizarPed = new Button();
            btnJson = new Button();
            btnFechar = new Button();
            btnResumoPedidos = new Button();
            btnPedidoTxt = new Button();
            btnPedidoXml = new Button();
            btnNovoPedido = new Button();
            TabPages = new TabControl();
            tbDp = new TabPage();
            btnLancarItens = new Button();
            lblHora = new Label();
            dtpInicio = new DateTimePicker();
            labelData = new Label();
            textBoxObs = new TextBox();
            lblObs = new Label();
            textBoxCliente = new TextBox();
            lblCliente = new Label();
            lblNumeroPedido = new Label();
            lblPedido = new Label();
            tbItem = new TabPage();
            lblValorTotal = new Label();
            lblTotal = new Label();
            dataGridView1 = new DataGridView();
            colunaItem = new DataGridViewTextBoxColumn();
            colunaDescricao = new DataGridViewTextBoxColumn();
            colunaQtd = new DataGridViewTextBoxColumn();
            colunaValorUnid = new DataGridViewTextBoxColumn();
            colunaTotal = new DataGridViewTextBoxColumn();
            lblNumeroPedidoItens = new Label();
            lblPedidoItens = new Label();
            groupBoxEscolha = new GroupBox();
            lblBarrinha = new Label();
            groupBox1 = new GroupBox();
            lblCodimentos = new Label();
            radioButtonCondNao = new RadioButton();
            radioButtonCondSim = new RadioButton();
            groupBox2 = new GroupBox();
            radioButtonBebNao = new RadioButton();
            radioButtonBebSim = new RadioButton();
            lblBebidas = new Label();
            grbBeb = new GroupBox();
            cmbBeb = new ComboBox();
            lblBebida = new Label();
            btnRemover = new Button();
            btnAdicionar = new Button();
            GrbCOnd = new GroupBox();
            checkBoxMolhoIngles = new CheckBox();
            checkBoxBatataPalha = new CheckBox();
            lblOpcoes = new Label();
            checkBoxPimenta = new CheckBox();
            checkBoxCatchup = new CheckBox();
            checkBoxMaionese = new CheckBox();
            checkBoxMostarda = new CheckBox();
            cmbPreço = new ComboBox();
            txtVitem = new TextBox();
            lblValorItem = new Label();
            txtQtd = new TextBox();
            lblQuantidade = new Label();
            lblPreco = new Label();
            cmbLanche = new ComboBox();
            lblLanche = new Label();
            tbPr = new TabPage();
            lblResumo = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            vScrollBar1 = new VScrollBar();
            dtpFim = new DateTimePicker();
            btnFiltrar = new Button();
            groupBoxAcoes.SuspendLayout();
            TabPages.SuspendLayout();
            tbDp.SuspendLayout();
            tbItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBoxEscolha.SuspendLayout();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            grbBeb.SuspendLayout();
            GrbCOnd.SuspendLayout();
            tbPr.SuspendLayout();
            SuspendLayout();
            // 
            // groupBoxAcoes
            // 
            groupBoxAcoes.BackColor = Color.Transparent;
            groupBoxAcoes.Controls.Add(BtnFInalizarPed);
            groupBoxAcoes.Controls.Add(btnJson);
            groupBoxAcoes.Controls.Add(btnFechar);
            groupBoxAcoes.Controls.Add(btnResumoPedidos);
            groupBoxAcoes.Controls.Add(btnPedidoTxt);
            groupBoxAcoes.Controls.Add(btnPedidoXml);
            groupBoxAcoes.Controls.Add(btnNovoPedido);
            groupBoxAcoes.ForeColor = SystemColors.Control;
            groupBoxAcoes.Location = new Point(17, 20);
            groupBoxAcoes.Margin = new Padding(4, 5, 4, 5);
            groupBoxAcoes.Name = "groupBoxAcoes";
            groupBoxAcoes.Padding = new Padding(4, 5, 4, 5);
            groupBoxAcoes.Size = new Size(1701, 210);
            groupBoxAcoes.TabIndex = 0;
            groupBoxAcoes.TabStop = false;
            groupBoxAcoes.Text = "Ações";
            // 
            // BtnFInalizarPed
            // 
            BtnFInalizarPed.BackColor = Color.DarkOrange;
            BtnFInalizarPed.Cursor = Cursors.Hand;
            BtnFInalizarPed.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            BtnFInalizarPed.Location = new Point(1296, 45);
            BtnFInalizarPed.Margin = new Padding(4, 5, 4, 5);
            BtnFInalizarPed.Name = "BtnFInalizarPed";
            BtnFInalizarPed.Size = new Size(176, 123);
            BtnFInalizarPed.TabIndex = 6;
            BtnFInalizarPed.Text = "Salvar no Banco";
            BtnFInalizarPed.UseVisualStyleBackColor = false;
            BtnFInalizarPed.Click += BtnFInalizarPed_Click;
            // 
            // btnJson
            // 
            btnJson.BackColor = Color.DarkOrange;
            btnJson.Cursor = Cursors.Hand;
            btnJson.Enabled = false;
            btnJson.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnJson.Location = new Point(1026, 45);
            btnJson.Margin = new Padding(4, 5, 4, 5);
            btnJson.Name = "btnJson";
            btnJson.Size = new Size(204, 123);
            btnJson.TabIndex = 6;
            btnJson.Text = "Salvar Pedido Json";
            btnJson.UseVisualStyleBackColor = false;
            btnJson.Click += btnJson_Click;
            // 
            // btnFechar
            // 
            btnFechar.BackColor = Color.DarkOrange;
            btnFechar.Cursor = Cursors.Hand;
            btnFechar.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnFechar.Location = new Point(1507, 45);
            btnFechar.Margin = new Padding(4, 5, 4, 5);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(176, 123);
            btnFechar.TabIndex = 5;
            btnFechar.Text = "Fechar";
            btnFechar.UseVisualStyleBackColor = false;
            // 
            // btnResumoPedidos
            // 
            btnResumoPedidos.BackColor = Color.DarkOrange;
            btnResumoPedidos.Cursor = Cursors.Hand;
            btnResumoPedidos.Enabled = false;
            btnResumoPedidos.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnResumoPedidos.Location = new Point(775, 45);
            btnResumoPedidos.Margin = new Padding(4, 5, 4, 5);
            btnResumoPedidos.Name = "btnResumoPedidos";
            btnResumoPedidos.Size = new Size(204, 123);
            btnResumoPedidos.TabIndex = 4;
            btnResumoPedidos.Text = "Resumo dos Pedidos";
            btnResumoPedidos.UseVisualStyleBackColor = false;
            btnResumoPedidos.Click += btnResumoPedidos_Click;
            // 
            // btnPedidoTxt
            // 
            btnPedidoTxt.BackColor = Color.DarkOrange;
            btnPedidoTxt.Cursor = Cursors.Hand;
            btnPedidoTxt.Enabled = false;
            btnPedidoTxt.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnPedidoTxt.Location = new Point(513, 45);
            btnPedidoTxt.Margin = new Padding(4, 5, 4, 5);
            btnPedidoTxt.Name = "btnPedidoTxt";
            btnPedidoTxt.Size = new Size(204, 123);
            btnPedidoTxt.TabIndex = 2;
            btnPedidoTxt.Text = "Gravar Pedido TXT";
            btnPedidoTxt.UseVisualStyleBackColor = false;
            btnPedidoTxt.Click += btnPedidoTxt_Click;
            // 
            // btnPedidoXml
            // 
            btnPedidoXml.BackColor = Color.DarkOrange;
            btnPedidoXml.Cursor = Cursors.Hand;
            btnPedidoXml.Enabled = false;
            btnPedidoXml.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnPedidoXml.Location = new Point(270, 45);
            btnPedidoXml.Margin = new Padding(4, 5, 4, 5);
            btnPedidoXml.Name = "btnPedidoXml";
            btnPedidoXml.Size = new Size(204, 123);
            btnPedidoXml.TabIndex = 1;
            btnPedidoXml.Text = "Gravar Pedido XML";
            btnPedidoXml.UseVisualStyleBackColor = false;
            btnPedidoXml.Click += btnPedidoXml_Click;
            // 
            // btnNovoPedido
            // 
            btnNovoPedido.BackColor = Color.DarkOrange;
            btnNovoPedido.Cursor = Cursors.Hand;
            btnNovoPedido.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Underline);
            btnNovoPedido.Location = new Point(30, 45);
            btnNovoPedido.Margin = new Padding(4, 5, 4, 5);
            btnNovoPedido.Name = "btnNovoPedido";
            btnNovoPedido.Size = new Size(204, 123);
            btnNovoPedido.TabIndex = 0;
            btnNovoPedido.Text = "Novo Pedido";
            btnNovoPedido.UseVisualStyleBackColor = false;
            btnNovoPedido.Click += btnNovoPedido_Click;
            // 
            // TabPages
            // 
            TabPages.Controls.Add(tbDp);
            TabPages.Controls.Add(tbItem);
            TabPages.Controls.Add(tbPr);
            TabPages.Location = new Point(17, 250);
            TabPages.Margin = new Padding(4, 5, 4, 5);
            TabPages.Name = "TabPages";
            TabPages.SelectedIndex = 0;
            TabPages.Size = new Size(1433, 723);
            TabPages.TabIndex = 1;
            // 
            // tbDp
            // 
            tbDp.BackColor = Color.Transparent;
            tbDp.Controls.Add(btnFiltrar);
            tbDp.Controls.Add(dtpFim);
            tbDp.Controls.Add(btnLancarItens);
            tbDp.Controls.Add(lblHora);
            tbDp.Controls.Add(dtpInicio);
            tbDp.Controls.Add(labelData);
            tbDp.Controls.Add(textBoxObs);
            tbDp.Controls.Add(lblObs);
            tbDp.Controls.Add(textBoxCliente);
            tbDp.Controls.Add(lblCliente);
            tbDp.Controls.Add(lblNumeroPedido);
            tbDp.Controls.Add(lblPedido);
            tbDp.ForeColor = SystemColors.ControlLight;
            tbDp.Location = new Point(4, 34);
            tbDp.Margin = new Padding(4, 5, 4, 5);
            tbDp.Name = "tbDp";
            tbDp.Padding = new Padding(4, 5, 4, 5);
            tbDp.Size = new Size(1425, 685);
            tbDp.TabIndex = 0;
            tbDp.Text = "Dados do Pedido";
            // 
            // btnLancarItens
            // 
            btnLancarItens.BackColor = Color.DarkOrange;
            btnLancarItens.Cursor = Cursors.Hand;
            btnLancarItens.Enabled = false;
            btnLancarItens.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLancarItens.ForeColor = SystemColors.Control;
            btnLancarItens.Location = new Point(1077, 507);
            btnLancarItens.Margin = new Padding(4, 5, 4, 5);
            btnLancarItens.Name = "btnLancarItens";
            btnLancarItens.Size = new Size(311, 140);
            btnLancarItens.TabIndex = 6;
            btnLancarItens.Text = "Lançar Itens ⇉";
            btnLancarItens.UseVisualStyleBackColor = false;
            btnLancarItens.Click += btnLancarItens_Click;
            // 
            // lblHora
            // 
            lblHora.AutoSize = true;
            lblHora.BackColor = Color.Transparent;
            lblHora.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHora.ForeColor = SystemColors.ActiveCaptionText;
            lblHora.Location = new Point(37, 550);
            lblHora.Margin = new Padding(4, 0, 4, 0);
            lblHora.Name = "lblHora";
            lblHora.Size = new Size(159, 48);
            lblHora.TabIndex = 8;
            lblHora.Text = "Horário:";
            // 
            // dtpInicio
            // 
            dtpInicio.Location = new Point(275, 390);
            dtpInicio.Margin = new Padding(4, 5, 4, 5);
            dtpInicio.Name = "dtpInicio";
            dtpInicio.Size = new Size(351, 31);
            dtpInicio.TabIndex = 7;
            // 
            // labelData
            // 
            labelData.AutoSize = true;
            labelData.BackColor = Color.Transparent;
            labelData.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            labelData.ForeColor = SystemColors.ActiveCaptionText;
            labelData.Location = new Point(37, 373);
            labelData.Margin = new Padding(4, 0, 4, 0);
            labelData.Name = "labelData";
            labelData.Size = new Size(109, 48);
            labelData.TabIndex = 6;
            labelData.Text = "Data:";
            // 
            // textBoxObs
            // 
            textBoxObs.Location = new Point(266, 235);
            textBoxObs.Margin = new Padding(4, 5, 4, 5);
            textBoxObs.Multiline = true;
            textBoxObs.Name = "textBoxObs";
            textBoxObs.Size = new Size(351, 89);
            textBoxObs.TabIndex = 5;
            // 
            // lblObs
            // 
            lblObs.AutoSize = true;
            lblObs.BackColor = Color.Transparent;
            lblObs.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblObs.ForeColor = SystemColors.ActiveCaptionText;
            lblObs.Location = new Point(37, 235);
            lblObs.Margin = new Padding(4, 0, 4, 0);
            lblObs.Name = "lblObs";
            lblObs.Size = new Size(95, 48);
            lblObs.TabIndex = 4;
            lblObs.Text = "Obs:";
            // 
            // textBoxCliente
            // 
            textBoxCliente.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textBoxCliente.Location = new Point(266, 153);
            textBoxCliente.Margin = new Padding(4, 5, 4, 5);
            textBoxCliente.Name = "textBoxCliente";
            textBoxCliente.Size = new Size(351, 31);
            textBoxCliente.TabIndex = 3;
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.BackColor = Color.Transparent;
            lblCliente.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblCliente.ForeColor = SystemColors.ActiveCaptionText;
            lblCliente.Location = new Point(37, 135);
            lblCliente.Margin = new Padding(4, 0, 4, 0);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(146, 48);
            lblCliente.TabIndex = 2;
            lblCliente.Text = "Cliente:";
            // 
            // lblNumeroPedido
            // 
            lblNumeroPedido.BorderStyle = BorderStyle.Fixed3D;
            lblNumeroPedido.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblNumeroPedido.ForeColor = SystemColors.ActiveCaptionText;
            lblNumeroPedido.Location = new Point(266, 43);
            lblNumeroPedido.Margin = new Padding(4, 0, 4, 0);
            lblNumeroPedido.Name = "lblNumeroPedido";
            lblNumeroPedido.Size = new Size(73, 50);
            lblNumeroPedido.TabIndex = 1;
            lblNumeroPedido.Text = "?";
            lblNumeroPedido.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblPedido
            // 
            lblPedido.AutoSize = true;
            lblPedido.BackColor = Color.Transparent;
            lblPedido.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPedido.ForeColor = SystemColors.ActiveCaptionText;
            lblPedido.Location = new Point(37, 45);
            lblPedido.Margin = new Padding(4, 0, 4, 0);
            lblPedido.Name = "lblPedido";
            lblPedido.Size = new Size(183, 45);
            lblPedido.TabIndex = 0;
            lblPedido.Text = "Pedido N°:";
            // 
            // tbItem
            // 
            tbItem.BackColor = Color.Transparent;
            tbItem.Controls.Add(lblValorTotal);
            tbItem.Controls.Add(lblTotal);
            tbItem.Controls.Add(dataGridView1);
            tbItem.Controls.Add(lblNumeroPedidoItens);
            tbItem.Controls.Add(lblPedidoItens);
            tbItem.Controls.Add(groupBoxEscolha);
            tbItem.Location = new Point(4, 34);
            tbItem.Margin = new Padding(4, 5, 4, 5);
            tbItem.Name = "tbItem";
            tbItem.Padding = new Padding(4, 5, 4, 5);
            tbItem.Size = new Size(1425, 685);
            tbItem.TabIndex = 1;
            tbItem.Text = "Itens";
            // 
            // lblValorTotal
            // 
            lblValorTotal.AutoSize = true;
            lblValorTotal.BackColor = Color.DarkOrange;
            lblValorTotal.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblValorTotal.ForeColor = SystemColors.Control;
            lblValorTotal.Location = new Point(1211, 627);
            lblValorTotal.Margin = new Padding(4, 0, 4, 0);
            lblValorTotal.Name = "lblValorTotal";
            lblValorTotal.Size = new Size(112, 40);
            lblValorTotal.TabIndex = 5;
            lblValorTotal.Text = "R$ 0,00";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.BackColor = Color.DarkOrange;
            lblTotal.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTotal.ForeColor = SystemColors.Control;
            lblTotal.Location = new Point(1123, 627);
            lblTotal.Margin = new Padding(4, 0, 4, 0);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(84, 40);
            lblTotal.TabIndex = 4;
            lblTotal.Text = "Total:";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.LightGray;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { colunaItem, colunaDescricao, colunaQtd, colunaValorUnid, colunaTotal });
            dataGridView1.EditMode = DataGridViewEditMode.EditProgrammatically;
            dataGridView1.Location = new Point(694, 117);
            dataGridView1.Margin = new Padding(4, 5, 4, 5);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(706, 505);
            dataGridView1.TabIndex = 3;
            // 
            // colunaItem
            // 
            colunaItem.HeaderText = "Item";
            colunaItem.MinimumWidth = 8;
            colunaItem.Name = "colunaItem";
            colunaItem.ReadOnly = true;
            colunaItem.Width = 50;
            // 
            // colunaDescricao
            // 
            colunaDescricao.HeaderText = "Descrição";
            colunaDescricao.MinimumWidth = 8;
            colunaDescricao.Name = "colunaDescricao";
            colunaDescricao.ReadOnly = true;
            colunaDescricao.Width = 200;
            // 
            // colunaQtd
            // 
            colunaQtd.HeaderText = "Qtd";
            colunaQtd.MinimumWidth = 8;
            colunaQtd.Name = "colunaQtd";
            colunaQtd.ReadOnly = true;
            colunaQtd.Width = 50;
            // 
            // colunaValorUnid
            // 
            colunaValorUnid.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colunaValorUnid.HeaderText = "$Unid";
            colunaValorUnid.MinimumWidth = 8;
            colunaValorUnid.Name = "colunaValorUnid";
            colunaValorUnid.ReadOnly = true;
            // 
            // colunaTotal
            // 
            colunaTotal.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            colunaTotal.HeaderText = "Total";
            colunaTotal.MinimumWidth = 8;
            colunaTotal.Name = "colunaTotal";
            colunaTotal.ReadOnly = true;
            // 
            // lblNumeroPedidoItens
            // 
            lblNumeroPedidoItens.AutoSize = true;
            lblNumeroPedidoItens.BackColor = Color.White;
            lblNumeroPedidoItens.Location = new Point(800, 63);
            lblNumeroPedidoItens.Margin = new Padding(4, 0, 4, 0);
            lblNumeroPedidoItens.Name = "lblNumeroPedidoItens";
            lblNumeroPedidoItens.Size = new Size(20, 25);
            lblNumeroPedidoItens.TabIndex = 2;
            lblNumeroPedidoItens.Text = "?";
            // 
            // lblPedidoItens
            // 
            lblPedidoItens.AutoSize = true;
            lblPedidoItens.BackColor = Color.White;
            lblPedidoItens.Location = new Point(694, 63);
            lblPedidoItens.Margin = new Padding(4, 0, 4, 0);
            lblPedidoItens.Name = "lblPedidoItens";
            lblPedidoItens.Size = new Size(96, 25);
            lblPedidoItens.TabIndex = 1;
            lblPedidoItens.Text = "Pedido N°:";
            // 
            // groupBoxEscolha
            // 
            groupBoxEscolha.Controls.Add(lblBarrinha);
            groupBoxEscolha.Controls.Add(groupBox1);
            groupBoxEscolha.Controls.Add(groupBox2);
            groupBoxEscolha.Controls.Add(grbBeb);
            groupBoxEscolha.Controls.Add(btnRemover);
            groupBoxEscolha.Controls.Add(btnAdicionar);
            groupBoxEscolha.Controls.Add(GrbCOnd);
            groupBoxEscolha.Controls.Add(cmbPreço);
            groupBoxEscolha.Controls.Add(txtVitem);
            groupBoxEscolha.Controls.Add(lblValorItem);
            groupBoxEscolha.Controls.Add(txtQtd);
            groupBoxEscolha.Controls.Add(lblQuantidade);
            groupBoxEscolha.Controls.Add(lblPreco);
            groupBoxEscolha.Controls.Add(cmbLanche);
            groupBoxEscolha.Controls.Add(lblLanche);
            groupBoxEscolha.ForeColor = SystemColors.ActiveCaptionText;
            groupBoxEscolha.Location = new Point(24, 43);
            groupBoxEscolha.Margin = new Padding(4, 5, 4, 5);
            groupBoxEscolha.Name = "groupBoxEscolha";
            groupBoxEscolha.Padding = new Padding(4, 5, 4, 5);
            groupBoxEscolha.Size = new Size(646, 627);
            groupBoxEscolha.TabIndex = 0;
            groupBoxEscolha.TabStop = false;
            groupBoxEscolha.Text = "Escolha";
            // 
            // lblBarrinha
            // 
            lblBarrinha.Location = new Point(1, 128);
            lblBarrinha.Margin = new Padding(4, 0, 4, 0);
            lblBarrinha.Name = "lblBarrinha";
            lblBarrinha.Size = new Size(631, 32);
            lblBarrinha.TabIndex = 7;
            lblBarrinha.Text = "_______________________________________________________________________________________________________________________________________";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblCodimentos);
            groupBox1.Controls.Add(radioButtonCondNao);
            groupBox1.Controls.Add(radioButtonCondSim);
            groupBox1.Location = new Point(7, 165);
            groupBox1.Margin = new Padding(4, 5, 4, 5);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(4, 5, 4, 5);
            groupBox1.Size = new Size(331, 167);
            groupBox1.TabIndex = 21;
            groupBox1.TabStop = false;
            // 
            // lblCodimentos
            // 
            lblCodimentos.AutoSize = true;
            lblCodimentos.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCodimentos.Location = new Point(11, 33);
            lblCodimentos.Margin = new Padding(4, 0, 4, 0);
            lblCodimentos.Name = "lblCodimentos";
            lblCodimentos.Size = new Size(225, 45);
            lblCodimentos.TabIndex = 8;
            lblCodimentos.Text = "Condimentos?";
            // 
            // radioButtonCondNao
            // 
            radioButtonCondNao.AutoSize = true;
            radioButtonCondNao.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButtonCondNao.Location = new Point(111, 83);
            radioButtonCondNao.Margin = new Padding(4, 5, 4, 5);
            radioButtonCondNao.Name = "radioButtonCondNao";
            radioButtonCondNao.Size = new Size(83, 36);
            radioButtonCondNao.TabIndex = 10;
            radioButtonCondNao.TabStop = true;
            radioButtonCondNao.Text = "Não";
            radioButtonCondNao.UseVisualStyleBackColor = true;
            radioButtonCondNao.CheckedChanged += radioButtonCondNao_CheckedChanged;
            // 
            // radioButtonCondSim
            // 
            radioButtonCondSim.AutoSize = true;
            radioButtonCondSim.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButtonCondSim.Location = new Point(21, 83);
            radioButtonCondSim.Margin = new Padding(4, 5, 4, 5);
            radioButtonCondSim.Name = "radioButtonCondSim";
            radioButtonCondSim.Size = new Size(79, 36);
            radioButtonCondSim.TabIndex = 9;
            radioButtonCondSim.TabStop = true;
            radioButtonCondSim.Text = "Sim";
            radioButtonCondSim.UseVisualStyleBackColor = true;
            radioButtonCondSim.CheckedChanged += radioButtonCondSim_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioButtonBebNao);
            groupBox2.Controls.Add(radioButtonBebSim);
            groupBox2.Controls.Add(lblBebidas);
            groupBox2.Location = new Point(354, 165);
            groupBox2.Margin = new Padding(4, 5, 4, 5);
            groupBox2.Name = "groupBox2";
            groupBox2.Padding = new Padding(4, 5, 4, 5);
            groupBox2.Size = new Size(276, 167);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            // 
            // radioButtonBebNao
            // 
            radioButtonBebNao.AutoSize = true;
            radioButtonBebNao.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButtonBebNao.Location = new Point(110, 83);
            radioButtonBebNao.Margin = new Padding(4, 5, 4, 5);
            radioButtonBebNao.Name = "radioButtonBebNao";
            radioButtonBebNao.Size = new Size(83, 36);
            radioButtonBebNao.TabIndex = 20;
            radioButtonBebNao.TabStop = true;
            radioButtonBebNao.Text = "Não";
            radioButtonBebNao.UseVisualStyleBackColor = true;
            radioButtonBebNao.CheckedChanged += radioButtonBebNao_CheckedChanged;
            // 
            // radioButtonBebSim
            // 
            radioButtonBebSim.AutoSize = true;
            radioButtonBebSim.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            radioButtonBebSim.Location = new Point(20, 83);
            radioButtonBebSim.Margin = new Padding(4, 5, 4, 5);
            radioButtonBebSim.Name = "radioButtonBebSim";
            radioButtonBebSim.Size = new Size(79, 36);
            radioButtonBebSim.TabIndex = 19;
            radioButtonBebSim.TabStop = true;
            radioButtonBebSim.Text = "Sim";
            radioButtonBebSim.UseVisualStyleBackColor = true;
            radioButtonBebSim.CheckedChanged += radioButtonBebSim_CheckedChanged;
            // 
            // lblBebidas
            // 
            lblBebidas.AutoSize = true;
            lblBebidas.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBebidas.Location = new Point(11, 33);
            lblBebidas.Margin = new Padding(4, 0, 4, 0);
            lblBebidas.Name = "lblBebidas";
            lblBebidas.Size = new Size(131, 45);
            lblBebidas.TabIndex = 18;
            lblBebidas.Text = "Bebidas";
            // 
            // grbBeb
            // 
            grbBeb.Controls.Add(cmbBeb);
            grbBeb.Controls.Add(lblBebida);
            grbBeb.Enabled = false;
            grbBeb.Location = new Point(366, 350);
            grbBeb.Margin = new Padding(4, 5, 4, 5);
            grbBeb.Name = "grbBeb";
            grbBeb.Padding = new Padding(4, 5, 4, 5);
            grbBeb.Size = new Size(267, 122);
            grbBeb.TabIndex = 26;
            grbBeb.TabStop = false;
            // 
            // cmbBeb
            // 
            cmbBeb.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbBeb.FormattingEnabled = true;
            cmbBeb.Location = new Point(24, 70);
            cmbBeb.Margin = new Padding(4, 5, 4, 5);
            cmbBeb.Name = "cmbBeb";
            cmbBeb.Size = new Size(215, 33);
            cmbBeb.TabIndex = 22;
            // 
            // lblBebida
            // 
            lblBebida.AutoSize = true;
            lblBebida.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblBebida.Location = new Point(9, 18);
            lblBebida.Margin = new Padding(4, 0, 4, 0);
            lblBebida.Name = "lblBebida";
            lblBebida.Size = new Size(117, 45);
            lblBebida.TabIndex = 21;
            lblBebida.Text = "Bebida";
            // 
            // btnRemover
            // 
            btnRemover.BackColor = Color.DarkOrange;
            btnRemover.Cursor = Cursors.Hand;
            btnRemover.Location = new Point(389, 543);
            btnRemover.Margin = new Padding(4, 5, 4, 5);
            btnRemover.Name = "btnRemover";
            btnRemover.Size = new Size(216, 53);
            btnRemover.TabIndex = 24;
            btnRemover.Text = "← Remover";
            btnRemover.UseVisualStyleBackColor = false;
            btnRemover.Click += btnRemover_Click;
            // 
            // btnAdicionar
            // 
            btnAdicionar.BackColor = Color.DarkOrange;
            btnAdicionar.Cursor = Cursors.Hand;
            btnAdicionar.Location = new Point(389, 482);
            btnAdicionar.Margin = new Padding(4, 5, 4, 5);
            btnAdicionar.Name = "btnAdicionar";
            btnAdicionar.Size = new Size(216, 53);
            btnAdicionar.TabIndex = 23;
            btnAdicionar.Text = "Adicionar →";
            btnAdicionar.UseVisualStyleBackColor = false;
            btnAdicionar.Click += btnAdicionar_Click;
            // 
            // GrbCOnd
            // 
            GrbCOnd.Controls.Add(checkBoxMolhoIngles);
            GrbCOnd.Controls.Add(checkBoxBatataPalha);
            GrbCOnd.Controls.Add(lblOpcoes);
            GrbCOnd.Controls.Add(checkBoxPimenta);
            GrbCOnd.Controls.Add(checkBoxCatchup);
            GrbCOnd.Controls.Add(checkBoxMaionese);
            GrbCOnd.Controls.Add(checkBoxMostarda);
            GrbCOnd.Enabled = false;
            GrbCOnd.Location = new Point(7, 350);
            GrbCOnd.Margin = new Padding(4, 3, 4, 3);
            GrbCOnd.Name = "GrbCOnd";
            GrbCOnd.Padding = new Padding(4, 3, 4, 3);
            GrbCOnd.Size = new Size(350, 247);
            GrbCOnd.TabIndex = 18;
            GrbCOnd.TabStop = false;
            // 
            // checkBoxMolhoIngles
            // 
            checkBoxMolhoIngles.AutoSize = true;
            checkBoxMolhoIngles.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxMolhoIngles.Location = new Point(156, 123);
            checkBoxMolhoIngles.Margin = new Padding(4, 5, 4, 5);
            checkBoxMolhoIngles.Name = "checkBoxMolhoIngles";
            checkBoxMolhoIngles.Size = new Size(180, 36);
            checkBoxMolhoIngles.TabIndex = 16;
            checkBoxMolhoIngles.Text = "Molho Inglês";
            checkBoxMolhoIngles.UseVisualStyleBackColor = true;
            // 
            // checkBoxBatataPalha
            // 
            checkBoxBatataPalha.AutoSize = true;
            checkBoxBatataPalha.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxBatataPalha.Location = new Point(156, 172);
            checkBoxBatataPalha.Margin = new Padding(4, 5, 4, 5);
            checkBoxBatataPalha.Name = "checkBoxBatataPalha";
            checkBoxBatataPalha.Size = new Size(169, 36);
            checkBoxBatataPalha.TabIndex = 17;
            checkBoxBatataPalha.Text = "Batata Palha";
            checkBoxBatataPalha.UseVisualStyleBackColor = true;
            // 
            // lblOpcoes
            // 
            lblOpcoes.AutoSize = true;
            lblOpcoes.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblOpcoes.Location = new Point(7, 18);
            lblOpcoes.Margin = new Padding(4, 0, 4, 0);
            lblOpcoes.Name = "lblOpcoes";
            lblOpcoes.Size = new Size(128, 45);
            lblOpcoes.TabIndex = 11;
            lblOpcoes.Text = "Opções";
            // 
            // checkBoxPimenta
            // 
            checkBoxPimenta.AutoSize = true;
            checkBoxPimenta.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxPimenta.Location = new Point(156, 82);
            checkBoxPimenta.Margin = new Padding(4, 5, 4, 5);
            checkBoxPimenta.Name = "checkBoxPimenta";
            checkBoxPimenta.Size = new Size(127, 36);
            checkBoxPimenta.TabIndex = 15;
            checkBoxPimenta.Text = "Pimenta";
            checkBoxPimenta.UseVisualStyleBackColor = true;
            // 
            // checkBoxCatchup
            // 
            checkBoxCatchup.AutoSize = true;
            checkBoxCatchup.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxCatchup.Location = new Point(11, 82);
            checkBoxCatchup.Margin = new Padding(4, 5, 4, 5);
            checkBoxCatchup.Name = "checkBoxCatchup";
            checkBoxCatchup.Size = new Size(128, 36);
            checkBoxCatchup.TabIndex = 12;
            checkBoxCatchup.Text = "Catchup";
            checkBoxCatchup.UseVisualStyleBackColor = true;
            // 
            // checkBoxMaionese
            // 
            checkBoxMaionese.AutoSize = true;
            checkBoxMaionese.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxMaionese.Location = new Point(11, 172);
            checkBoxMaionese.Margin = new Padding(4, 5, 4, 5);
            checkBoxMaionese.Name = "checkBoxMaionese";
            checkBoxMaionese.Size = new Size(144, 36);
            checkBoxMaionese.TabIndex = 14;
            checkBoxMaionese.Text = "Maionese";
            checkBoxMaionese.UseVisualStyleBackColor = true;
            // 
            // checkBoxMostarda
            // 
            checkBoxMostarda.AutoSize = true;
            checkBoxMostarda.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            checkBoxMostarda.Location = new Point(11, 123);
            checkBoxMostarda.Margin = new Padding(4, 5, 4, 5);
            checkBoxMostarda.Name = "checkBoxMostarda";
            checkBoxMostarda.Size = new Size(140, 36);
            checkBoxMostarda.TabIndex = 13;
            checkBoxMostarda.Text = "Mostarda";
            checkBoxMostarda.UseVisualStyleBackColor = true;
            // 
            // cmbPreço
            // 
            cmbPreço.DropDownStyle = ComboBoxStyle.Simple;
            cmbPreço.Enabled = false;
            cmbPreço.FormattingEnabled = true;
            cmbPreço.Items.AddRange(new object[] { "23,90  ", "R$25,50  ", "R$24,80  ", "R$27,90  ", "R$22,70  ", "R$24,30  ", "R$21,50" });
            cmbPreço.Location = new Point(227, 82);
            cmbPreço.Margin = new Padding(4, 5, 4, 5);
            cmbPreço.Name = "cmbPreço";
            cmbPreço.Size = new Size(124, 34);
            cmbPreço.TabIndex = 25;
            cmbPreço.SelectedIndexChanged += comboBoxLanche_SelectedIndexChanged;
            // 
            // txtVitem
            // 
            txtVitem.Enabled = false;
            txtVitem.Location = new Point(493, 82);
            txtVitem.Margin = new Padding(4, 5, 4, 5);
            txtVitem.Multiline = true;
            txtVitem.Name = "txtVitem";
            txtVitem.Size = new Size(137, 32);
            txtVitem.TabIndex = 7;
            // 
            // lblValorItem
            // 
            lblValorItem.AutoSize = true;
            lblValorItem.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblValorItem.Location = new Point(459, 30);
            lblValorItem.Margin = new Padding(4, 0, 4, 0);
            lblValorItem.Name = "lblValorItem";
            lblValorItem.Size = new Size(173, 45);
            lblValorItem.TabIndex = 6;
            lblValorItem.Text = "Valor Item:";
            // 
            // txtQtd
            // 
            txtQtd.Location = new Point(366, 82);
            txtQtd.Margin = new Padding(4, 5, 4, 5);
            txtQtd.Name = "txtQtd";
            txtQtd.Size = new Size(118, 31);
            txtQtd.TabIndex = 5;
            txtQtd.TextChanged += txtQtd_TextChanged;
            txtQtd.KeyPress += txtQtd_KeyPress;
            // 
            // lblQuantidade
            // 
            lblQuantidade.AutoSize = true;
            lblQuantidade.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblQuantidade.Location = new Point(366, 30);
            lblQuantidade.Margin = new Padding(4, 0, 4, 0);
            lblQuantidade.Name = "lblQuantidade";
            lblQuantidade.Size = new Size(81, 45);
            lblQuantidade.TabIndex = 4;
            lblQuantidade.Text = "Qtd:";
            // 
            // lblPreco
            // 
            lblPreco.AutoSize = true;
            lblPreco.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPreco.Location = new Point(227, 30);
            lblPreco.Margin = new Padding(4, 0, 4, 0);
            lblPreco.Name = "lblPreco";
            lblPreco.Size = new Size(107, 45);
            lblPreco.TabIndex = 2;
            lblPreco.Text = "Preço:";
            // 
            // cmbLanche
            // 
            cmbLanche.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbLanche.FormattingEnabled = true;
            cmbLanche.Location = new Point(7, 82);
            cmbLanche.Margin = new Padding(4, 5, 4, 5);
            cmbLanche.Name = "cmbLanche";
            cmbLanche.Size = new Size(210, 33);
            cmbLanche.TabIndex = 1;
            cmbLanche.SelectedIndexChanged += comboBoxLanche_SelectedIndexChanged;
            // 
            // lblLanche
            // 
            lblLanche.AutoSize = true;
            lblLanche.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLanche.Location = new Point(7, 30);
            lblLanche.Margin = new Padding(4, 0, 4, 0);
            lblLanche.Name = "lblLanche";
            lblLanche.Size = new Size(126, 45);
            lblLanche.TabIndex = 0;
            lblLanche.Text = "Lanche:";
            // 
            // tbPr
            // 
            tbPr.BackColor = Color.DarkOrange;
            tbPr.Controls.Add(lblResumo);
            tbPr.Location = new Point(4, 34);
            tbPr.Margin = new Padding(4, 5, 4, 5);
            tbPr.Name = "tbPr";
            tbPr.Size = new Size(1425, 685);
            tbPr.TabIndex = 2;
            tbPr.Text = "Resumo dos Pedidos";
            // 
            // lblResumo
            // 
            lblResumo.AccessibleRole = AccessibleRole.ScrollBar;
            lblResumo.Location = new Point(207, 27);
            lblResumo.Margin = new Padding(4, 5, 4, 5);
            lblResumo.Multiline = true;
            lblResumo.Name = "lblResumo";
            lblResumo.Size = new Size(977, 627);
            lblResumo.TabIndex = 1;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // vScrollBar1
            // 
            vScrollBar1.Location = new Point(1581, 258);
            vScrollBar1.Name = "vScrollBar1";
            vScrollBar1.Size = new Size(8, 13);
            vScrollBar1.TabIndex = 2;
            // 
            // dtpFim
            // 
            dtpFim.Location = new Point(275, 459);
            dtpFim.Name = "dtpFim";
            dtpFim.Size = new Size(351, 31);
            dtpFim.TabIndex = 9;
            // 
            // btnFiltrar
            // 
            btnFiltrar.Location = new Point(683, 425);
            btnFiltrar.Name = "btnFiltrar";
            btnFiltrar.Size = new Size(112, 34);
            btnFiltrar.TabIndex = 10;
            btnFiltrar.Text = "button1";
            btnFiltrar.UseVisualStyleBackColor = true;
            btnFiltrar.Click += btnFiltrar_Click;
            // 
            // formLanchonete
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Menu;
            ClientSize = new Size(1924, 1012);
            Controls.Add(vScrollBar1);
            Controls.Add(TabPages);
            Controls.Add(groupBoxAcoes);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 5, 4, 5);
            Name = "formLanchonete";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ItaLanches";
            groupBoxAcoes.ResumeLayout(false);
            TabPages.ResumeLayout(false);
            tbDp.ResumeLayout(false);
            tbDp.PerformLayout();
            tbItem.ResumeLayout(false);
            tbItem.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBoxEscolha.ResumeLayout(false);
            groupBoxEscolha.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            grbBeb.ResumeLayout(false);
            grbBeb.PerformLayout();
            GrbCOnd.ResumeLayout(false);
            GrbCOnd.PerformLayout();
            tbPr.ResumeLayout(false);
            tbPr.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBoxAcoes;
        private Button btnPedidoTxt;
        private Button btnPedidoXml;
        private Button btnNovoPedido;
        private Button btnFechar;
        private Button btnResumoPedidos;
        private TabControl TabPages;
        private TabPage tbDp;
        private TabPage tbItem;
        private TextBox textBoxCliente;
        private Label lblCliente;
        private Label lblNumeroPedido;
        private Label lblPedido;
        private TabPage tbPr;
        private Label labelData;
        private TextBox textBoxObs;
        private Label lblObs;
        private Label lblHora;
        private DateTimePicker dtpInicio;
        private System.Windows.Forms.Timer timer1;
        private Button btnLancarItens;
        private GroupBox groupBoxEscolha;
        private ComboBox cmbLanche;
        private Label lblLanche;
        private Label lblPreco;
        private Label lblQuantidade;
        private TextBox txtVitem;
        private Label lblValorItem;
        private TextBox txtQtd;
        private Label lblCodimentos;
        private Label lblOpcoes;
        private RadioButton radioButtonCondNao;
        private RadioButton radioButtonCondSim;
        private RadioButton radioButtonBebNao;
        private RadioButton radioButtonBebSim;
        private Label lblBebidas;
        private CheckBox checkBoxBatataPalha;
        private CheckBox checkBoxMolhoIngles;
        private CheckBox checkBoxPimenta;
        private CheckBox checkBoxMaionese;
        private CheckBox checkBoxMostarda;
        private CheckBox checkBoxCatchup;
        private Button btnAdicionar;
        private ComboBox cmbBeb;
        private Label lblBebida;
        private Button btnRemover;
        private Label lblNumeroPedidoItens;
        private Label lblPedidoItens;
        private DataGridView dataGridView1;
        private Label lblValorTotal;
        private Label lblTotal;
        private ComboBox cmbPreço;
        private GroupBox GrbCOnd;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private GroupBox grbBeb;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private DataGridViewTextBoxColumn colunaItem;
        private DataGridViewTextBoxColumn colunaDescricao;
        private DataGridViewTextBoxColumn colunaQtd;
        private DataGridViewTextBoxColumn colunaValorUnid;
        private DataGridViewTextBoxColumn colunaTotal;
        private Label lblBarrinha;
        private Button btnJson;
        private TextBox lblResumo;
        private VScrollBar vScrollBar1;
        private Button BtnFInalizarPed;
        private DateTimePicker dtpFim;
        private Button btnFiltrar;
    }
}
