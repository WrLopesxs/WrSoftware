-- Script de cria��o das tabelas do sistema de lanchonete
-- Desenvolvido por Wender

CREATE DATABASE Lanchonete;
GO

USE Lanchonete;
GO

-- Tabela de Usu�rios
CREATE TABLE UsuariosLancho (
    Id INT PRIMARY KEY IDENTITY(1,1),
    NomeUsuario NVARCHAR(50) NOT NULL,
    Senha NVARCHAR(255) NOT NULL,
    NivelAcesso NVARCHAR(20) NOT NULL
);
GO

INSERT INTO UsuariosLancho (NomeUsuario, Senha, NivelAcesso)
VALUES 
  ('admin', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Administrador'),
  ('Cozinha', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', 'Cozinha');
GO


-- Tabela de Clientes
CREATE TABLE Clientes (
    id INT PRIMARY KEY IDENTITY(1,1),
    Nome NVARCHAR(100) NOT NULL,
    CPF CHAR(11),
    Email NVARCHAR(100),
    Telefone NVARCHAR(20),
    DataNascimento DATE,
    Endereco NVARCHAR(200),
    CEP CHAR(8)
);
GO

-- Tabela de Produtos
CREATE TABLE Produtos (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100) NOT NULL,
    pre�o DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL
);
GO

-- Tabela de Bebidas
CREATE TABLE Bebidas (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100) NOT NULL,
    pre�o DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL
);
GO

-- Tabela de Condimentos
CREATE TABLE Condimentos (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome NVARCHAR(100) NOT NULL
);
GO


CREATE TABLE Pedidos (
   
    clinte NVARCHAR(100) ,
    DataPedido DATETIME NOT NULL DEFAULT GETDATE(),
    Total DECIMAL(10,2) NOT NULL,
    observacao nvarchar(255),

);
GO
drop table PedidosItens
-- Tabela de Itens do Pedido
CREATE TABLE PedidosItens (
  
    pedido_id INT NOT NULL,
    item_nome varchar(100)not NULL,   
    quantidade varchar(100) NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL
   
);
GO

-- Inserts iniciais (opcional)
INSERT INTO Produtos (nome, pre�o, estoque)
VALUES ('X-Burger', 12.00, 50), ('X-Salada', 14.00, 30);
GO

INSERT INTO Bebidas (nome, pre�o, estoque)
VALUES ('Coca-Cola 350ml', 5.50, 100), ('Suco Natural', 6.00, 60);
GO

INSERT INTO Condimentos (nome)
VALUES ('Ketchup'), ('Maionese'), ('Mostarda');
GO
